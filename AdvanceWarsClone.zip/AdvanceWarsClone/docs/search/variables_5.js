var searchData=
[
  ['healamount',['healAmount',['../classcityscript.html#af718abb17fbf96aa9fe50ea2ebd6e79d',1,'cityscript']]],
  ['health',['Health',['../class_unit_status.html#a49e3dd749288712879418ca7c5f518a1',1,'UnitStatus']]]
];
