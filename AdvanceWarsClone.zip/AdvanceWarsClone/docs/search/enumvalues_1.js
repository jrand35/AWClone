var searchData=
[
  ['dead',['dead',['../class_unit_state.html#a11778e7802f408c643497706dbd9e808af58e6a506c76fc2c90a7d29cbc631c2f',1,'UnitState.dead()'],['../class_unit_state_controller.html#a9d9a0225df378c04935b45f09aab1e9aaf58e6a506c76fc2c90a7d29cbc631c2f',1,'UnitStateController.dead()']]]
];
