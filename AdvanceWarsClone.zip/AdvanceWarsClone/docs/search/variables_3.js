var searchData=
[
  ['defense',['Defense',['../class_unit_status.html#a2e98452e7bf508015a13372bd6ab4358',1,'UnitStatus']]]
];
