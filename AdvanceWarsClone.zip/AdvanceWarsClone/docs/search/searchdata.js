var indexSectionsWithContent =
{
  0: "abcdfghimoprstu",
  1: "chmsu",
  2: "chmsu",
  3: "agmu",
  4: "abcdfhimoprstu",
  5: "mu",
  6: "adimst",
  7: "ou"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Events"
};

