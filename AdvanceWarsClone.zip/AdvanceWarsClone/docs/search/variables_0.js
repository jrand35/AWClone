var searchData=
[
  ['attack',['Attack',['../class_unit_status.html#ac77031ef05d0854d8aee995b424475a5',1,'UnitStatus']]]
];
