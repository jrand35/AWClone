var searchData=
[
  ['parentgameobject',['ParentGameObject',['../class_unit_status.html#a6579a1955a0f90815ef3206efeb88776',1,'UnitStatus']]]
];
